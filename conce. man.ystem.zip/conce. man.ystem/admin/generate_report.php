<?php
session_start();
include("dbconnection.php");
include("checklogin.php");
check_login();

if (isset($_POST['report_type'])) {
  $reportType = $_POST['report_type'];

  if ($reportType == 'specific_date') {
    $date = $_POST['report_date'];
    $query = "SELECT * FROM ticket WHERE DATE(posting_date) = '$date' ORDER BY id DESC";
  } else if ($reportType == 'all_tickets') {
    $query = "SELECT * FROM ticket ORDER BY id DESC";
  }

  $rt = mysqli_query($con, $query);
} else {
  // Handle case when no report type is selected
  // You can redirect the user to the ticket list or display an error message
  // For example: header("Location: view_ticket.php");
}
?>

<!DOCTYPE html>
<html>
<head>
<!-- Remaining HTML head content -->
</head>
<body class="">
<!-- Remaining HTML body content -->
</body>
</html>
