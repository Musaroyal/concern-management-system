<?php
$con=mysqli_connect("pdb58.awardspace.net", "4089676_grading", "Lebo@12345", "4089676_grading");
if(mysqli_connect_errno()){
echo "Connection Fail".mysqli_connect_error();
}

?>
