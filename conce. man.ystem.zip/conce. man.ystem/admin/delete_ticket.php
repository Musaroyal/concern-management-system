<?php
session_start();
include("dbconnection.php");
include("checklogin.php");
check_login();

if (isset($_GET['id'])) {
  $ticketId = $_GET['id'];

  $query = "DELETE FROM ticket WHERE id='$ticketId'";
  $result = mysqli_query($con, $query);

  if ($result) {
    echo '<script>alert("Ticket has been deleted."); location.replace(document.referrer)</script>';
  } else {
    echo '<script>alert("Failed to delete ticket."); location.replace(document.referrer)</script>';
  }
}
?>
