<?php
session_start();
include("dbconnection.php");
include("checklogin.php");
check_login();

// Check if the report generation button is clicked
if (isset($_GET['generate_report'])) {
  // Fetch all the tickets from the database with department name
  $query = "SELECT t.*, d.name
            FROM ticket AS t
            INNER JOIN daptment AS d ON t.dep_id = d.dep_id";
  $result = mysqli_query($con, $query);

  // Create a CSV file for the report
  $filename = 'ticket_report.csv';
  $file = fopen($filename, 'w');

  // Write the headers in the CSV file
  $headers = array('User email', 'Subject','', 'Date','', 'Staff Remark','', 'Status','', 'Department', 'Photo');
  fputcsv($file, $headers);

  // Write the ticket data in the CSV file
  while ($row = mysqli_fetch_assoc($result)) {
    $data = array($row['email_id'], $row['subject'],'', $row['posting_date'],'', $row['admin_remark'],'', $row['status'],'', $row['name'], $row['image']);
    fputcsv($file, $data);
  }

  fclose($file);

  // Read the CSV file contents
  $csvContents = file_get_contents($filename);
  unlink($filename); // Delete the temporary CSV file

  // Output the CSV contents as an HTML table
  echo '<table>';
  echo '<thead>';
  echo '<tr>';
  
  echo '</tr>';
  echo '</thead>';
  echo '<tbody>';
  $rows = explode("\n", $csvContents);
  foreach ($rows as $row) {
    echo '<tr>';
    $columns = str_getcsv($row);
    foreach ($columns as $column) {
      echo '<td>' . $column . '</td>';
    }
    echo '</tr>';
  }
  echo '</tbody>';
  echo '</table>';

  exit();
}
?>
